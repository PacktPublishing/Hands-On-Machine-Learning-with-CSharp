using System;

namespace numl.Math.LinearAlgebra
{
    public enum VectorType
    {
        Row,
        Col
    }
}

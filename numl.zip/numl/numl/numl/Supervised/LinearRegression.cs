﻿using System;
using System.Linq;
using numl.Math.LinearAlgebra;
using System.Collections.Generic;

namespace numl.Supervised
{
    public class LinearRegressionGenerator : Generator
    {
        public override IModel Generate(Matrix x, Vector y)
        {
            //x.NormalizeRows(2);

            throw new NotImplementedException();
        }
    }
}

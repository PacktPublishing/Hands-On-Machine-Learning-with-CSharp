﻿namespace SharpRBM.SimpleLetterDemo
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.startButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.stopButton = new System.Windows.Forms.Button();
            this.hiddenNodesTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.inputImagesTextBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.featureDetectors = new System.Windows.Forms.PictureBox();
            this.featureDetectorsGroupBox = new System.Windows.Forms.GroupBox();
            this.drawFeatureDetectorsCheckBox = new System.Windows.Forms.CheckBox();
            this.increaseContrastCheckBox = new System.Windows.Forms.CheckBox();
            this.enableBiasDuringFeatureDetectorRenderCheckBox = new System.Windows.Forms.CheckBox();
            this.reconstructedPictureBox = new System.Windows.Forms.PictureBox();
            this.inputBictureBox = new System.Windows.Forms.PictureBox();
            this.useBiasCheckBox = new System.Windows.Forms.CheckBox();
            this.drawReconstructionsCheckBox = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.featureDetectors)).BeginInit();
            this.featureDetectorsGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reconstructedPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(299, 20);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(55, 25);
            this.startButton.TabIndex = 1;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "(none)";
            // 
            // stopButton
            // 
            this.stopButton.Location = new System.Drawing.Point(360, 20);
            this.stopButton.Name = "stopButton";
            this.stopButton.Size = new System.Drawing.Size(55, 25);
            this.stopButton.TabIndex = 7;
            this.stopButton.Text = "Stop";
            this.stopButton.UseVisualStyleBackColor = true;
            this.stopButton.Click += new System.EventHandler(this.stopButton_Click);
            // 
            // hiddenNodesTextBox
            // 
            this.hiddenNodesTextBox.Location = new System.Drawing.Point(12, 26);
            this.hiddenNodesTextBox.Name = "hiddenNodesTextBox";
            this.hiddenNodesTextBox.Size = new System.Drawing.Size(94, 20);
            this.hiddenNodesTextBox.TabIndex = 8;
            this.hiddenNodesTextBox.Text = "100";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Hidden nodes (>0)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(112, 11);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Input images (1-255)";
            // 
            // inputImagesTextBox
            // 
            this.inputImagesTextBox.Location = new System.Drawing.Point(112, 26);
            this.inputImagesTextBox.Name = "inputImagesTextBox";
            this.inputImagesTextBox.Size = new System.Drawing.Size(103, 20);
            this.inputImagesTextBox.TabIndex = 10;
            this.inputImagesTextBox.Text = "10";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Progress";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 85);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 13);
            this.label5.TabIndex = 23;
            this.label5.Text = "Inputs (first x)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 132);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(141, 13);
            this.label6.TabIndex = 34;
            this.label6.Text = "Reconstructed inputs (first x)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 179);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 36;
            // 
            // featureDetectors
            // 
            this.featureDetectors.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.featureDetectors.Location = new System.Drawing.Point(6, 19);
            this.featureDetectors.Name = "featureDetectors";
            this.featureDetectors.Size = new System.Drawing.Size(815, 419);
            this.featureDetectors.TabIndex = 36;
            this.featureDetectors.TabStop = false;
            // 
            // featureDetectorsGroupBox
            // 
            this.featureDetectorsGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.featureDetectorsGroupBox.Controls.Add(this.drawFeatureDetectorsCheckBox);
            this.featureDetectorsGroupBox.Controls.Add(this.increaseContrastCheckBox);
            this.featureDetectorsGroupBox.Controls.Add(this.enableBiasDuringFeatureDetectorRenderCheckBox);
            this.featureDetectorsGroupBox.Controls.Add(this.featureDetectors);
            this.featureDetectorsGroupBox.Location = new System.Drawing.Point(12, 195);
            this.featureDetectorsGroupBox.Name = "featureDetectorsGroupBox";
            this.featureDetectorsGroupBox.Size = new System.Drawing.Size(827, 444);
            this.featureDetectorsGroupBox.TabIndex = 37;
            this.featureDetectorsGroupBox.TabStop = false;
            this.featureDetectorsGroupBox.Text = "Feature detectors (first x)";
            // 
            // drawFeatureDetectorsCheckBox
            // 
            this.drawFeatureDetectorsCheckBox.AutoSize = true;
            this.drawFeatureDetectorsCheckBox.Location = new System.Drawing.Point(259, 0);
            this.drawFeatureDetectorsCheckBox.Name = "drawFeatureDetectorsCheckBox";
            this.drawFeatureDetectorsCheckBox.Size = new System.Drawing.Size(51, 17);
            this.drawFeatureDetectorsCheckBox.TabIndex = 42;
            this.drawFeatureDetectorsCheckBox.Text = "Draw";
            this.drawFeatureDetectorsCheckBox.UseVisualStyleBackColor = true;
            // 
            // increaseContrastCheckBox
            // 
            this.increaseContrastCheckBox.AutoSize = true;
            this.increaseContrastCheckBox.Location = new System.Drawing.Point(547, 0);
            this.increaseContrastCheckBox.Name = "increaseContrastCheckBox";
            this.increaseContrastCheckBox.Size = new System.Drawing.Size(108, 17);
            this.increaseContrastCheckBox.TabIndex = 41;
            this.increaseContrastCheckBox.Text = "Increase contrast";
            this.increaseContrastCheckBox.UseVisualStyleBackColor = true;
            // 
            // enableBiasDuringFeatureDetectorRenderCheckBox
            // 
            this.enableBiasDuringFeatureDetectorRenderCheckBox.AutoSize = true;
            this.enableBiasDuringFeatureDetectorRenderCheckBox.Location = new System.Drawing.Point(316, 0);
            this.enableBiasDuringFeatureDetectorRenderCheckBox.Name = "enableBiasDuringFeatureDetectorRenderCheckBox";
            this.enableBiasDuringFeatureDetectorRenderCheckBox.Size = new System.Drawing.Size(225, 17);
            this.enableBiasDuringFeatureDetectorRenderCheckBox.TabIndex = 37;
            this.enableBiasDuringFeatureDetectorRenderCheckBox.Text = "Enable Bias during feature detector render";
            this.enableBiasDuringFeatureDetectorRenderCheckBox.UseVisualStyleBackColor = true;
            // 
            // reconstructedPictureBox
            // 
            this.reconstructedPictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.reconstructedPictureBox.Location = new System.Drawing.Point(18, 148);
            this.reconstructedPictureBox.Name = "reconstructedPictureBox";
            this.reconstructedPictureBox.Size = new System.Drawing.Size(815, 28);
            this.reconstructedPictureBox.TabIndex = 38;
            this.reconstructedPictureBox.TabStop = false;
            // 
            // inputBictureBox
            // 
            this.inputBictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.inputBictureBox.Location = new System.Drawing.Point(18, 101);
            this.inputBictureBox.Name = "inputBictureBox";
            this.inputBictureBox.Size = new System.Drawing.Size(815, 28);
            this.inputBictureBox.TabIndex = 39;
            this.inputBictureBox.TabStop = false;
            // 
            // useBiasCheckBox
            // 
            this.useBiasCheckBox.AutoSize = true;
            this.useBiasCheckBox.Checked = true;
            this.useBiasCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.useBiasCheckBox.Location = new System.Drawing.Point(225, 28);
            this.useBiasCheckBox.Name = "useBiasCheckBox";
            this.useBiasCheckBox.Size = new System.Drawing.Size(68, 17);
            this.useBiasCheckBox.TabIndex = 40;
            this.useBiasCheckBox.Text = "Use Bias";
            this.useBiasCheckBox.UseVisualStyleBackColor = true;
            // 
            // drawReconstructionsCheckBox
            // 
            this.drawReconstructionsCheckBox.AutoSize = true;
            this.drawReconstructionsCheckBox.Checked = true;
            this.drawReconstructionsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.drawReconstructionsCheckBox.Location = new System.Drawing.Point(162, 131);
            this.drawReconstructionsCheckBox.Name = "drawReconstructionsCheckBox";
            this.drawReconstructionsCheckBox.Size = new System.Drawing.Size(51, 17);
            this.drawReconstructionsCheckBox.TabIndex = 46;
            this.drawReconstructionsCheckBox.Text = "Draw";
            this.drawReconstructionsCheckBox.UseVisualStyleBackColor = true;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(844, 641);
            this.Controls.Add(this.drawReconstructionsCheckBox);
            this.Controls.Add(this.useBiasCheckBox);
            this.Controls.Add(this.inputBictureBox);
            this.Controls.Add(this.reconstructedPictureBox);
            this.Controls.Add(this.featureDetectorsGroupBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.inputImagesTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.hiddenNodesTextBox);
            this.Controls.Add(this.stopButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.startButton);
            this.Name = "MainForm";
            this.Text = "Simple Letter Demo";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            this.SizeChanged += new System.EventHandler(this.MainForm_SizeChanged);
            ((System.ComponentModel.ISupportInitialize)(this.featureDetectors)).EndInit();
            this.featureDetectorsGroupBox.ResumeLayout(false);
            this.featureDetectorsGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reconstructedPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button stopButton;
        private System.Windows.Forms.TextBox hiddenNodesTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox inputImagesTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox featureDetectors;
        private System.Windows.Forms.GroupBox featureDetectorsGroupBox;
        private System.Windows.Forms.PictureBox reconstructedPictureBox;
        private System.Windows.Forms.PictureBox inputBictureBox;
        private System.Windows.Forms.CheckBox useBiasCheckBox;
        private System.Windows.Forms.CheckBox enableBiasDuringFeatureDetectorRenderCheckBox;
        private System.Windows.Forms.CheckBox increaseContrastCheckBox;
        private System.Windows.Forms.CheckBox drawFeatureDetectorsCheckBox;
        private System.Windows.Forms.CheckBox drawReconstructionsCheckBox;
    }
}


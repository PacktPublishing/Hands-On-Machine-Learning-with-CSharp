﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace SharpRBM.Core
{
    public static class SerializationHelper
    {
        public static T LoadFromFile<T>(string fileName)
        {
            BinaryFormatter formatter = new BinaryFormatter();            
            using (Stream stream = File.Open(fileName, FileMode.Open))
            {
                return (T)formatter.Deserialize(stream);
            }
        }

        public static void SaveToFile<T>(T obj, string fileName)
        {
            BinaryFormatter formatter = new BinaryFormatter();
            using (Stream stream = File.Open(fileName, FileMode.Create))
            {
                formatter.Serialize(stream, obj);             
            }
        }
    }
}

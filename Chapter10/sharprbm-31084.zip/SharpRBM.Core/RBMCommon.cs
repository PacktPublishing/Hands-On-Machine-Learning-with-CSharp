﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpRBM.Core
{
    public static class RBMCommon
    {
        private static Random _random = new Random();
        public static Random Random { get { return _random; } }
    }
}

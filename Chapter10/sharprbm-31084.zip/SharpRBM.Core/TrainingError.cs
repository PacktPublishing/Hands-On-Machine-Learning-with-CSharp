﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpRBM.Core
{
    [Serializable]
    public class TrainingError
    {
        internal TrainingError()
        { 
        }

        internal TrainingError(float featureDetectorError, float reconstructionError)
        {
            FeatureDetectorError = featureDetectorError;
            ReconstructionError = reconstructionError;
        }

        public float FeatureDetectorError { get; set; }
        public double ReconstructionError { get; set; }
    }
}

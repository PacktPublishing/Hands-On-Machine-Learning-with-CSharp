﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpRBM.Core
{
    public class Layer
    {
        private int _size;
        private static bool _useBias = true;

        public Layer(int size)
            : this(size, new float[size])
        {
        }

        public Layer(int size, params float[] values)
        {
            _size = size;
            Values = values;
            SetBias();
            if (values.Count() != size)
            {
                throw new ArgumentException("values");
            }
        }

        public static bool UseBias { get { return _useBias; } set { _useBias = value; } }
        public int Size { get { return _size; } }
        public float[] Values { get; set; }

        public Layer Clone()
        {
            Layer layer = new Layer(Size);
            layer.Values = Values.ToList().ToArray();
            return layer;
        }

        public void ClearValues()
        {
            SetValues(0);
            SetBias();
        }

        public void SetBias()
        {
            // First node is always the bias node!
            if (UseBias)
            {
                Values[0] = 1.01F;
            }            
        }

        public void SetValues(float value)
        {
            // Skip bias
            for (int i = 0; i < _size; i++)
            {
                Values[i] = value;
            }
            SetBias();
        }

        internal void CopyBinary(Layer input)
        {
            Helper.Loop(Size, i =>
                {
                    if (Helper.Random.NextDouble() <= input.Values[i])
                    {
                        Values[i] = 1;
                    }
                    else
                    {
                        Values[i] = 0;
                    }
                });

            SetBias();
        }
    }
}

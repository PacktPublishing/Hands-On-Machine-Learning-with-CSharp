﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SharpRBM.Core.Enumerations;

namespace SharpRBM.Core.LearningModules
{
    public interface ILearningModule : IDisposable
    {
        void Prepare(InterLayerWeights weights, List<Layer> inputs);
        TrainingError Train();
        void ActivateLowerToUpper(Layer lower, Layer upper, ActivationMethod method);
        void ActivateUpperToLower(Layer lower, Layer upper);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpRBM.Core.LearningModules
{
    public static class LearningModuleHelper
    {
        public static float[] CreateRawTestCases(List<Layer> testCases, int lowerLayerSize)
        {
            float[] rawTestCases = new float[testCases.Count * lowerLayerSize];

            for (int testCase = 0; testCase < testCases.Count; testCase++)
            {
                Layer layer = testCases[testCase];
                int testCaseOffset = testCase * lowerLayerSize;
                for (int pos = 0; pos < lowerLayerSize; pos++)
                {
                    rawTestCases[testCaseOffset + pos] = layer.Values[pos];
                }
            }

            return rawTestCases;
        }
    }
}

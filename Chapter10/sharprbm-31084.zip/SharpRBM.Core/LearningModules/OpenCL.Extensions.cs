﻿using System;
using System.Collections.Generic;
using System.Linq;
using SharpRBM.Core.Enumerations;
using System.Runtime.InteropServices;

// Borrowed from OpenClooVision - http://opencloovision.codeplex.com/
namespace OpenCL.Net
{
    /// <summary>
    /// Extension class methods for Cloo
    /// </summary>
    public static class OpenCLExtensions
    {
        private static int _intPtrSize = -1;
        public static int IntPtrSize
        {
            get
            {
                if (_intPtrSize == -1)
                {
                    unsafe
                    {
                        _intPtrSize = sizeof(IntPtr);
                    }
                }
                return _intPtrSize;
            }
        }

        public static Cl.Kernel CreateKernel(this Cl.Program program, string kernelName)
        {
            Cl.ErrorCode error;
            Cl.Kernel kernel = Cl.CreateKernel(program, kernelName, out error);
            if (error != Cl.ErrorCode.Success)
            {
                throw new InvalidProgramException(string.Format("Unable to run Cl.CreateKernel for {1}: {0}!", error, kernelName));
            }
            return kernel;
        }

        public static Cl.Kernel SetKernelArg<T>( this Cl.Kernel kernel, uint argId, T value )
        {
            GCHandle gcHandle = GCHandle.Alloc( value, GCHandleType.Pinned );
            try
            {
                Cl.ErrorCode error = Cl.SetKernelArg( kernel, argId, new IntPtr( Marshal.SizeOf( typeof( T ) ) ), gcHandle.AddrOfPinnedObject() );

                if( error != Cl.ErrorCode.Success )
                {
                    throw new InvalidProgramException( string.Format( "Unable to run Cl.SetKernelArg<T>: {0}!", error ) );
                }
            }
            finally
            {
                gcHandle.Free();
            }

            return kernel;
        }

        public static Cl.Kernel SetKernelArg(this Cl.Kernel kernel, uint argId, Cl.Mem mem, int size)
        {
            Cl.ErrorCode error = Cl.SetKernelArg(kernel, argId, new IntPtr(size), mem);
            if (error != Cl.ErrorCode.Success)
            {
                throw new InvalidProgramException(string.Format("Unable to run Cl.SetKernelArg: {0}!", error));
            }
            return kernel;
        }

        public static Cl.Kernel SetKernelArgValue( this Cl.Kernel kernel, uint argId, Cl.Mem mem )
        {
            return kernel.SetKernelArg( argId, mem, sizeof( float ) );
        }

        public static Cl.Kernel SetKernelArgFloat(this Cl.Kernel kernel, uint argId, Cl.Mem mem)
        {
            return kernel.SetKernelArg(argId, mem, sizeof(float));
        }

        public static Cl.Kernel SetKernelArgBool(this Cl.Kernel kernel, uint argId, Cl.Mem mem)
        {
            return kernel.SetKernelArg(argId, mem, sizeof(Cl.Bool));
        }

        public static void EnqueueNDRangeKernel(this Cl.Kernel kernel, Cl.CommandQueue commandQueue, params int[] sizes)
        {
            Cl.Event clevent;
            Cl.ErrorCode error = Cl.EnqueueNDRangeKernel(
                commandQueue,
                kernel,
                (uint)sizes.Length,
                null,
                sizes.ToList().Select(size => new IntPtr(size)).ToArray(),
                null,
                0,
                null,
                out clevent);
            if (error != Cl.ErrorCode.Success)
            {
                throw new InvalidOperationException("EnqueueNDRangeKernel failed:" + error);
            }
            clevent.Dispose();
        }

        public static void EnqueueTask(this Cl.Kernel kernel, Cl.CommandQueue commandQueue)
        {
            Cl.Event clevent;
            Cl.ErrorCode error = Cl.EnqueueTask(
                commandQueue,
                kernel,
                0,
                null,
                out clevent);
            if (error != Cl.ErrorCode.Success)
            {
                throw new InvalidOperationException("EnqueueTask failed:" + error);
            }
            clevent.Dispose();
        }

        public static void Read(this Cl.Mem mem, Cl.CommandQueue commandQueue, int size, object data, BlockMode blockMode)
        {
            Cl.Event clevent;
            IntPtr event_handle = IntPtr.Zero;
            Cl.ErrorCode error = Cl.EnqueueReadBuffer(commandQueue, mem, blockMode == BlockMode.Blocking ? Cl.Bool.True : Cl.Bool.False, IntPtr.Zero, new IntPtr(size), data, 0, null, out clevent);
            if (error != Cl.ErrorCode.Success)
            {
                throw new InvalidOperationException("EnqueueReadBuffer failed for _weightsMem:" + error);
            }
            clevent.Dispose();
        }

        public static void ReadFloatArray(this Cl.Mem mem, Cl.CommandQueue commandQueue, float[] array, BlockMode blockMode)
        {
            mem.Read(commandQueue, sizeof(float) * array.Length, array, blockMode);
        }

        public static void Write(this Cl.Mem mem, Cl.CommandQueue commandQueue, int size, object data, BlockMode blockMode)
        {
            Cl.Event clevent;
            Cl.ErrorCode error = Cl.EnqueueWriteBuffer(commandQueue, mem, blockMode == BlockMode.Blocking ? Cl.Bool.True : Cl.Bool.False, IntPtr.Zero, new IntPtr(size), data, 0, null, out clevent);
            if (error != Cl.ErrorCode.Success)
            {
                throw new InvalidProgramException(string.Format("EnqueueWriteBuffer failed: {0}!", error));
            }
            clevent.Dispose();
        }

        public static void WriteFloatArray(this Cl.Mem mem, Cl.CommandQueue commandQueue, float[] array, BlockMode blockMode)
        {
            mem.Write(commandQueue, sizeof(float) * array.Length, array, blockMode);
        }


        public static Cl.Mem AllocateFloatArray(this Cl.Context context, float[] array, Cl.MemFlags flags)
        {
            Cl.ErrorCode error;
            int size = sizeof(float) * array.Count();
            Cl.Mem result = Cl.CreateBuffer(context, flags, (IntPtr)size, array, out error);
            if (error != Cl.ErrorCode.Success)
            {
                throw new InvalidProgramException(string.Format("CreateBuffer failed:", error));
            }
            return result;
        }

        public static Cl.Mem AllocateIntArray(this Cl.Context context, int[] array, Cl.MemFlags flags)
        {
            Cl.ErrorCode error;
            int size = 4 * array.Count();
            Cl.Mem result = Cl.CreateBuffer(context, flags, (IntPtr)size, array, out error);
            if (error != Cl.ErrorCode.Success)
            {
                throw new InvalidProgramException(string.Format("CreateBuffer failed:", error));
            }
            return result;
        }

        public static void Finish(this Cl.CommandQueue commandQueue)
        {
            Cl.ErrorCode error = Cl.Finish(commandQueue);
            if (error != Cl.ErrorCode.Success)
            {
                throw new InvalidProgramException(string.Format("Finish failed:", error));
            }
        }
        /*public static void SetMemoryArgument(this Cl.Kernel kernel, int argumentId, object value)
        {
            Cl.ErrorCode error = Cl.SetKernelArg(kernel, 0, new IntPtr(inPtrSize), hDeviceMemA);
            Assert.AreEqual(Cl.ErrorCode.Success, error);
        }

        public static void SetArguments(this Cl.Kernel kernel, params object[] args)
        {            
            for (int i = 0; i < args.Length; i++)
            {
                try
                {
                    object arg = args[i];
                    if (arg == null) { kernel.SetMemoryArgument(i, null); continue; }
                    var typeCode = Type.GetTypeCode(arg.GetType());
                    switch (typeCode)
                    {
                        //case TypeCode.Boolean:
                        //    break;
                        case TypeCode.Byte:
                            kernel.SetValueArgument<byte>(i, (byte)arg);
                            break;
                        case TypeCode.Char:
                            kernel.SetValueArgument<char>(i, (char)arg);
                            break;
                        //case TypeCode.DBNull:
                        //    break;
                        //case TypeCode.DateTime:
                        //    break;
                        case TypeCode.Decimal:
                            kernel.SetValueArgument<decimal>(i, (decimal)arg);
                            break;
                        case TypeCode.Double:
                            kernel.SetValueArgument<double>(i, (double)arg);
                            break;
                        case TypeCode.Empty:
                            kernel.SetMemoryArgument(i, null);
                            break;
                        case TypeCode.Int16:
                            kernel.SetValueArgument<short>(i, (short)arg);
                            break;
                        case TypeCode.Int32:
                            kernel.SetValueArgument<int>(i, (int)arg);
                            break;
                        case TypeCode.Int64:
                            kernel.SetValueArgument<long>(i, (long)arg);
                            break;
                        case TypeCode.Object:
                            {
                                ClooBuffer mem = arg as ClooBuffer;
                                if (mem != null) { kernel.SetMemoryArgument(i, mem.DeviceBuffer); continue; }
                            }
                            {
                                ComputeMemory mem = arg as ComputeMemory;
                                if (mem != null) { kernel.SetMemoryArgument(i, mem); continue; }
                            }
                            goto default;
                        case TypeCode.SByte:
                            kernel.SetValueArgument<sbyte>(i, (sbyte)arg);
                            break;
                        case TypeCode.Single:
                            kernel.SetValueArgument<float>(i, (float)arg);
                            break;
                        //case TypeCode.String:
                        //    break;
                        case TypeCode.UInt16:
                            kernel.SetValueArgument<ushort>(i, (ushort)arg);
                            break;
                        case TypeCode.UInt32:
                            kernel.SetValueArgument<uint>(i, (uint)arg);
                            break;
                        case TypeCode.UInt64:
                            kernel.SetValueArgument<ulong>(i, (ulong)arg);
                            break;
                        default:
                            throw new NotSupportedException("Type " + arg.GetType().ToString() + " is not supported as argument");
                    }
                }
                catch (InvalidKernelArgumentsComputeException)
                {
                    throw new ArgumentException(String.Format("Invalid kernel parameter specified on index {0} for function {1}", i, kernel.FunctionName));
                }
            }
        }*/
    }
}

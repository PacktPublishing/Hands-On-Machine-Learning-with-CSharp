﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpRBM.Core
{
    /// <summary>
    /// This is a temporary solution while I refactor
    /// </summary>
    public static class Variables
    {
        public static string DataPath = @"..\..\..\Data\";
        public static string VerifyPath = DataPath + @"MNIST\";
        public static string ImagePath = DataPath + @"MNIST\{0}_{1}.bmp";
        public static string DeepBeliefNetworkFile = DataPath + "LetterClassification-Trained.dbn";

        public static int InputImageCount = 16;// Note that this is multiplied by 10 (0,1,2,3,4,5,6,7,8,9 are counted individually)
        public static int SecondLayerSize = 500;
        public static int ThirdLayerSize = 500;
        public static int FourthLayerSize = 1000;

        public static int DreamNoiseNumeratorLow = 1;
        public static int DreamNoiseNumeratorHigh = 4;

        public static int DreamNoiseDenominatorLow = 6;
        public static int DreamNoiseDenominatorHigh = 10;

        public static double DreamNoiseBlastProbability = 0.2d;
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections.ObjectModel;

namespace SharpRBM.Core
{
    [Serializable]
    public class DeepBeliefNetwork
    {
        internal DeepBeliefNetwork()
        {
        }

        public DeepBeliefNetwork(params int[] layerSizes)
        {
            LayerSizes = layerSizes.ToList();
            GenerateLayerWeights();            
        }

        public List<int> LayerSizes { get; private set; }
        public List<InterLayerWeights> LayerWeights { get; private set; }

        public void AddNewLayer(int nodeCount)
        {
            InterLayerWeights last = LayerWeights.Last();
            LayerSizes.Add(nodeCount);

            InterLayerWeights weights = new InterLayerWeights(last.UpperLayerSize, nodeCount);
            LayerWeights.Add(weights);
        }

        private void GenerateLayerWeights()
        {
            LayerWeights = new List<InterLayerWeights>();
            Helper.Loop(LayerSizes.Count-1, layerIndex=>
                {
                    InterLayerWeights weights = new InterLayerWeights(LayerSizes[layerIndex], LayerSizes[layerIndex + 1]);
                    LayerWeights.Add(weights);
                });            
        }
    }
}

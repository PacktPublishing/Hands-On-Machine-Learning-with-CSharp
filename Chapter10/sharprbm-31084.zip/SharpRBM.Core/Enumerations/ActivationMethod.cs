﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpRBM.Core.Enumerations
{
    public enum ActivationMethod
    {
        Linear,
        Binary
    }
}

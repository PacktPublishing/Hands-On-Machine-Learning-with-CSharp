﻿namespace SharpRBM.LetterClassificationDemo
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.startButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.stopButton = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.inputsLabel = new System.Windows.Forms.Label();
            this.reconstructedLabel = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.featureDetectors = new System.Windows.Forms.PictureBox();
            this.featureDetectorsGroupBox = new System.Windows.Forms.GroupBox();
            this.drawFeatureDetectorsCheckBox = new System.Windows.Forms.CheckBox();
            this.increaseContrastCheckBox = new System.Windows.Forms.CheckBox();
            this.enableBiasDuringFeatureDetectorRenderCheckBox = new System.Windows.Forms.CheckBox();
            this.reconstructedPictureBox = new System.Windows.Forms.PictureBox();
            this.inputBictureBox = new System.Windows.Forms.PictureBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.trainThirdLayerRadioButton = new System.Windows.Forms.RadioButton();
            this.trainSecondLayerRadioButton = new System.Windows.Forms.RadioButton();
            this.trainFirstLayerRadioButton = new System.Windows.Forms.RadioButton();
            this.saveButton = new System.Windows.Forms.Button();
            this.loadButton = new System.Windows.Forms.Button();
            this.logTextBox = new System.Windows.Forms.TextBox();
            this.clearSelectedLayerButton = new System.Windows.Forms.Button();
            this.drawReconstructionsCheckBox = new System.Windows.Forms.CheckBox();
            this.dreamButton = new System.Windows.Forms.Button();
            this.dreamPictureBox = new System.Windows.Forms.PictureBox();
            this.createDBNbutton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.featureDetectors)).BeginInit();
            this.featureDetectorsGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reconstructedPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBictureBox)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dreamPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(455, 19);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(37, 25);
            this.startButton.TabIndex = 1;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 62);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "(none)";
            // 
            // stopButton
            // 
            this.stopButton.Location = new System.Drawing.Point(498, 19);
            this.stopButton.Name = "stopButton";
            this.stopButton.Size = new System.Drawing.Size(37, 25);
            this.stopButton.TabIndex = 7;
            this.stopButton.Text = "Stop";
            this.stopButton.UseVisualStyleBackColor = true;
            this.stopButton.Click += new System.EventHandler(this.stopButton_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 49);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "Progress";
            // 
            // inputsLabel
            // 
            this.inputsLabel.AutoSize = true;
            this.inputsLabel.Location = new System.Drawing.Point(15, 85);
            this.inputsLabel.Name = "inputsLabel";
            this.inputsLabel.Size = new System.Drawing.Size(69, 13);
            this.inputsLabel.TabIndex = 23;
            this.inputsLabel.Text = "Inputs (first x)";
            // 
            // reconstructedLabel
            // 
            this.reconstructedLabel.AutoSize = true;
            this.reconstructedLabel.Location = new System.Drawing.Point(15, 132);
            this.reconstructedLabel.Name = "reconstructedLabel";
            this.reconstructedLabel.Size = new System.Drawing.Size(141, 13);
            this.reconstructedLabel.TabIndex = 34;
            this.reconstructedLabel.Text = "Reconstructed inputs (first x)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 179);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 13);
            this.label7.TabIndex = 36;
            // 
            // featureDetectors
            // 
            this.featureDetectors.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.featureDetectors.Location = new System.Drawing.Point(6, 19);
            this.featureDetectors.Name = "featureDetectors";
            this.featureDetectors.Size = new System.Drawing.Size(838, 291);
            this.featureDetectors.TabIndex = 36;
            this.featureDetectors.TabStop = false;
            // 
            // featureDetectorsGroupBox
            // 
            this.featureDetectorsGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.featureDetectorsGroupBox.Controls.Add(this.drawFeatureDetectorsCheckBox);
            this.featureDetectorsGroupBox.Controls.Add(this.increaseContrastCheckBox);
            this.featureDetectorsGroupBox.Controls.Add(this.enableBiasDuringFeatureDetectorRenderCheckBox);
            this.featureDetectorsGroupBox.Controls.Add(this.featureDetectors);
            this.featureDetectorsGroupBox.Location = new System.Drawing.Point(12, 195);
            this.featureDetectorsGroupBox.Name = "featureDetectorsGroupBox";
            this.featureDetectorsGroupBox.Size = new System.Drawing.Size(850, 316);
            this.featureDetectorsGroupBox.TabIndex = 37;
            this.featureDetectorsGroupBox.TabStop = false;
            this.featureDetectorsGroupBox.Text = "Feature detectors (first x out of ?)";
            // 
            // drawFeatureDetectorsCheckBox
            // 
            this.drawFeatureDetectorsCheckBox.AutoSize = true;
            this.drawFeatureDetectorsCheckBox.Location = new System.Drawing.Point(220, 0);
            this.drawFeatureDetectorsCheckBox.Name = "drawFeatureDetectorsCheckBox";
            this.drawFeatureDetectorsCheckBox.Size = new System.Drawing.Size(51, 17);
            this.drawFeatureDetectorsCheckBox.TabIndex = 43;
            this.drawFeatureDetectorsCheckBox.Text = "Draw";
            this.drawFeatureDetectorsCheckBox.UseVisualStyleBackColor = true;
            // 
            // increaseContrastCheckBox
            // 
            this.increaseContrastCheckBox.AutoSize = true;
            this.increaseContrastCheckBox.Location = new System.Drawing.Point(500, 0);
            this.increaseContrastCheckBox.Name = "increaseContrastCheckBox";
            this.increaseContrastCheckBox.Size = new System.Drawing.Size(108, 17);
            this.increaseContrastCheckBox.TabIndex = 41;
            this.increaseContrastCheckBox.Text = "Increase contrast";
            this.increaseContrastCheckBox.UseVisualStyleBackColor = true;
            // 
            // enableBiasDuringFeatureDetectorRenderCheckBox
            // 
            this.enableBiasDuringFeatureDetectorRenderCheckBox.AutoSize = true;
            this.enableBiasDuringFeatureDetectorRenderCheckBox.Location = new System.Drawing.Point(269, 0);
            this.enableBiasDuringFeatureDetectorRenderCheckBox.Name = "enableBiasDuringFeatureDetectorRenderCheckBox";
            this.enableBiasDuringFeatureDetectorRenderCheckBox.Size = new System.Drawing.Size(225, 17);
            this.enableBiasDuringFeatureDetectorRenderCheckBox.TabIndex = 37;
            this.enableBiasDuringFeatureDetectorRenderCheckBox.Text = "Enable Bias during feature detector render";
            this.enableBiasDuringFeatureDetectorRenderCheckBox.UseVisualStyleBackColor = true;
            // 
            // reconstructedPictureBox
            // 
            this.reconstructedPictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.reconstructedPictureBox.Location = new System.Drawing.Point(18, 148);
            this.reconstructedPictureBox.Name = "reconstructedPictureBox";
            this.reconstructedPictureBox.Size = new System.Drawing.Size(838, 28);
            this.reconstructedPictureBox.TabIndex = 38;
            this.reconstructedPictureBox.TabStop = false;
            // 
            // inputBictureBox
            // 
            this.inputBictureBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.inputBictureBox.Location = new System.Drawing.Point(18, 101);
            this.inputBictureBox.Name = "inputBictureBox";
            this.inputBictureBox.Size = new System.Drawing.Size(838, 28);
            this.inputBictureBox.TabIndex = 39;
            this.inputBictureBox.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.trainThirdLayerRadioButton);
            this.groupBox2.Controls.Add(this.trainSecondLayerRadioButton);
            this.groupBox2.Controls.Add(this.trainFirstLayerRadioButton);
            this.groupBox2.Location = new System.Drawing.Point(15, 8);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(339, 38);
            this.groupBox2.TabIndex = 40;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Perform Step:";
            // 
            // trainThirdLayerRadioButton
            // 
            this.trainThirdLayerRadioButton.AutoSize = true;
            this.trainThirdLayerRadioButton.Location = new System.Drawing.Point(217, 19);
            this.trainThirdLayerRadioButton.Name = "trainThirdLayerRadioButton";
            this.trainThirdLayerRadioButton.Size = new System.Drawing.Size(97, 17);
            this.trainThirdLayerRadioButton.TabIndex = 2;
            this.trainThirdLayerRadioButton.Text = "Train third layer";
            this.trainThirdLayerRadioButton.UseVisualStyleBackColor = true;
            // 
            // trainSecondLayerRadioButton
            // 
            this.trainSecondLayerRadioButton.AutoSize = true;
            this.trainSecondLayerRadioButton.Location = new System.Drawing.Point(106, 19);
            this.trainSecondLayerRadioButton.Name = "trainSecondLayerRadioButton";
            this.trainSecondLayerRadioButton.Size = new System.Drawing.Size(112, 17);
            this.trainSecondLayerRadioButton.TabIndex = 1;
            this.trainSecondLayerRadioButton.Text = "Train second layer";
            this.trainSecondLayerRadioButton.UseVisualStyleBackColor = true;
            // 
            // trainFirstLayerRadioButton
            // 
            this.trainFirstLayerRadioButton.AutoSize = true;
            this.trainFirstLayerRadioButton.Checked = true;
            this.trainFirstLayerRadioButton.Location = new System.Drawing.Point(7, 19);
            this.trainFirstLayerRadioButton.Name = "trainFirstLayerRadioButton";
            this.trainFirstLayerRadioButton.Size = new System.Drawing.Size(93, 17);
            this.trainFirstLayerRadioButton.TabIndex = 0;
            this.trainFirstLayerRadioButton.TabStop = true;
            this.trainFirstLayerRadioButton.Text = "Train first layer";
            this.trainFirstLayerRadioButton.UseVisualStyleBackColor = true;
            // 
            // saveButton
            // 
            this.saveButton.Location = new System.Drawing.Point(408, 19);
            this.saveButton.Name = "saveButton";
            this.saveButton.Size = new System.Drawing.Size(41, 25);
            this.saveButton.TabIndex = 42;
            this.saveButton.Text = "Save";
            this.saveButton.UseVisualStyleBackColor = true;
            this.saveButton.Click += new System.EventHandler(this.saveButton_Click);
            // 
            // loadButton
            // 
            this.loadButton.Location = new System.Drawing.Point(360, 19);
            this.loadButton.Name = "loadButton";
            this.loadButton.Size = new System.Drawing.Size(42, 25);
            this.loadButton.TabIndex = 41;
            this.loadButton.Text = "Load";
            this.loadButton.UseVisualStyleBackColor = true;
            this.loadButton.Click += new System.EventHandler(this.loadButton_Click);
            // 
            // logTextBox
            // 
            this.logTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.logTextBox.Font = new System.Drawing.Font("Courier New", 8.25F);
            this.logTextBox.Location = new System.Drawing.Point(15, 517);
            this.logTextBox.Multiline = true;
            this.logTextBox.Name = "logTextBox";
            this.logTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.logTextBox.Size = new System.Drawing.Size(836, 112);
            this.logTextBox.TabIndex = 43;
            // 
            // clearSelectedLayerButton
            // 
            this.clearSelectedLayerButton.Location = new System.Drawing.Point(541, 19);
            this.clearSelectedLayerButton.Name = "clearSelectedLayerButton";
            this.clearSelectedLayerButton.Size = new System.Drawing.Size(117, 25);
            this.clearSelectedLayerButton.TabIndex = 44;
            this.clearSelectedLayerButton.Text = "Clear Selected Layer";
            this.clearSelectedLayerButton.UseVisualStyleBackColor = true;
            this.clearSelectedLayerButton.Click += new System.EventHandler(this.clearSelectedLayerButton_Click);
            // 
            // drawReconstructionsCheckBox
            // 
            this.drawReconstructionsCheckBox.AutoSize = true;
            this.drawReconstructionsCheckBox.Checked = true;
            this.drawReconstructionsCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.drawReconstructionsCheckBox.Location = new System.Drawing.Point(232, 131);
            this.drawReconstructionsCheckBox.Name = "drawReconstructionsCheckBox";
            this.drawReconstructionsCheckBox.Size = new System.Drawing.Size(51, 17);
            this.drawReconstructionsCheckBox.TabIndex = 45;
            this.drawReconstructionsCheckBox.Text = "Draw";
            this.drawReconstructionsCheckBox.UseVisualStyleBackColor = true;
            // 
            // dreamButton
            // 
            this.dreamButton.Location = new System.Drawing.Point(664, 19);
            this.dreamButton.Name = "dreamButton";
            this.dreamButton.Size = new System.Drawing.Size(50, 25);
            this.dreamButton.TabIndex = 46;
            this.dreamButton.Text = "Dream";
            this.dreamButton.UseVisualStyleBackColor = true;
            this.dreamButton.Click += new System.EventHandler(this.dreamButton_Click);
            // 
            // dreamPictureBox
            // 
            this.dreamPictureBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.dreamPictureBox.Location = new System.Drawing.Point(763, 97);
            this.dreamPictureBox.Name = "dreamPictureBox";
            this.dreamPictureBox.Size = new System.Drawing.Size(99, 92);
            this.dreamPictureBox.TabIndex = 47;
            this.dreamPictureBox.TabStop = false;
            // 
            // createDBNbutton
            // 
            this.createDBNbutton.Location = new System.Drawing.Point(720, 19);
            this.createDBNbutton.Name = "createDBNbutton";
            this.createDBNbutton.Size = new System.Drawing.Size(90, 25);
            this.createDBNbutton.TabIndex = 48;
            this.createDBNbutton.Text = "Create DBN...";
            this.createDBNbutton.UseVisualStyleBackColor = true;
            this.createDBNbutton.Click += new System.EventHandler(this.createDBNbutton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(867, 641);
            this.Controls.Add(this.createDBNbutton);
            this.Controls.Add(this.dreamPictureBox);
            this.Controls.Add(this.dreamButton);
            this.Controls.Add(this.drawReconstructionsCheckBox);
            this.Controls.Add(this.clearSelectedLayerButton);
            this.Controls.Add(this.logTextBox);
            this.Controls.Add(this.saveButton);
            this.Controls.Add(this.loadButton);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.inputBictureBox);
            this.Controls.Add(this.reconstructedPictureBox);
            this.Controls.Add(this.featureDetectorsGroupBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.reconstructedLabel);
            this.Controls.Add(this.inputsLabel);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.stopButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.startButton);
            this.Name = "MainForm";
            this.Text = "Letter Classification Demo";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.featureDetectors)).EndInit();
            this.featureDetectorsGroupBox.ResumeLayout(false);
            this.featureDetectorsGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reconstructedPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inputBictureBox)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dreamPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button stopButton;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label inputsLabel;
        private System.Windows.Forms.Label reconstructedLabel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox featureDetectors;
        private System.Windows.Forms.GroupBox featureDetectorsGroupBox;
        private System.Windows.Forms.PictureBox reconstructedPictureBox;
        private System.Windows.Forms.PictureBox inputBictureBox;
        private System.Windows.Forms.CheckBox enableBiasDuringFeatureDetectorRenderCheckBox;
        private System.Windows.Forms.CheckBox increaseContrastCheckBox;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton trainThirdLayerRadioButton;
        private System.Windows.Forms.RadioButton trainSecondLayerRadioButton;
        private System.Windows.Forms.RadioButton trainFirstLayerRadioButton;
        private System.Windows.Forms.Button saveButton;
        private System.Windows.Forms.Button loadButton;
        private System.Windows.Forms.TextBox logTextBox;
        private System.Windows.Forms.Button clearSelectedLayerButton;
        private System.Windows.Forms.CheckBox drawFeatureDetectorsCheckBox;
        private System.Windows.Forms.CheckBox drawReconstructionsCheckBox;
        private System.Windows.Forms.Button dreamButton;
        private System.Windows.Forms.PictureBox dreamPictureBox;
        private System.Windows.Forms.Button createDBNbutton;
    }
}

